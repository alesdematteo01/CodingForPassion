//
//  File.swift
//  AppDemo
//
//  Created by Alessandra De Matteo on 12/04/22.
//

import Foundation
import SwiftUI

struct LessonTabView : View{
        
    @State var columns: [GridItem] = [
        GridItem(.fixed(100), spacing: 308),
        GridItem(.fixed(100), spacing: 308)
    ]
    
    var body: some View{
        ScrollView(.vertical, showsIndicators: false){
            LazyVGrid(columns: columns, alignment: .leading, spacing: 32){
                
                ForEach(lessonsAvaibles.indices, id: \.self) { index in
                    let emoji = lessonsAvaibles[index].lessonEmoji
                    let number = lessonsAvaibles[index].lessonNumber
                    let description = lessonsAvaibles[index].lessonDescription
                    
                    NavigationLink(destination: LessonView(lessonChosen: lessonsAvaibles[index])) {
                        VStack{
                            ZStack{
                                Circle()
                                    .foregroundColor(.white)
                                    .frame(width: 150, height: 150, alignment: .center)
                                Text("\(emoji)")
                                    .font(.system(size: 70))
                            }
                            .padding()
                            Text("\(description)")
                                .font(.title)
                                .font(.system(size: 30))
                                .foregroundColor(.black)
                                .padding()
                            Text("Lesson \(number)")
                                .font(.system(size: 22))
                                .foregroundColor(.gray)
                        }
                    }
                    .frame(width: 375, height: 400)
                    .background(lessonsAvaibles[index].lessonColor)
                    .cornerRadius(10)
                    .shadow(radius: 3)
                }
            }
            .padding(24)
        }
        .navigationTitle("Choose your activity!")
    }
}
