import SwiftUI

// Fare i gradienti 

struct ContentView: View {
    
    @State var showLessons: Bool = false
    
    var body: some View {
        NavigationView{
            VStack{
                Text("Welcome to")
                    .font(.system(size: 80))
                    .bold()
                Text("Coding for Passion!")
                    .font(.system(size: 80))
                    .bold()
                    .padding(.bottom)
                Text("Your best tool to improve your coding knowledge")
                    .font(.system(size: 30))
                    .font(.subheadline)
                    .padding()
                    .foregroundColor(.gray)
                Text("Please, select what you wanto to do next")
                    .foregroundColor(.gray)
                    .font(.system(size: 25))
                    .padding(.bottom)
                NavigationLink(destination: LessonTabView()) {
                    Text("🍇 Lessons  ")
                        .font(.system(size: 40))
                        .bold()
                }
                .frame(width: UIScreen.main.bounds.width - 150, height: 160, alignment: .center)
                .background(Color.reddish)
                .foregroundColor(Color.white)
                .cornerRadius(10)
                NavigationLink(destination: QuestionationariesTabView()) {
                    Text("🥞 Questionaries  ")
                        .font(.system(size: 40))
                        .bold()
                }
                .frame(width: UIScreen.main.bounds.width - 150, height: 160, alignment: .center)
                .background(Color.orangish)
                .foregroundColor(Color.white)
                .cornerRadius(10)
                NavigationLink(destination: ExercisesTabView()) {
                    Text("🥮 Exercises  ")
                        .font(.system(size: 40))
                        .bold()
                }
                .frame(width: UIScreen.main.bounds.width - 150, height: 160, alignment: .center)
                .background(Color.bluish)
                .foregroundColor(Color.white)
                .cornerRadius(10)
                NavigationLink(destination: InfoView()) {
                    Text("Info")
                        .font(.system(size: 25))
                        .underline()
                }
                .frame(width: UIScreen.main.bounds.width - 300, height: 75, alignment: .center)
                .foregroundColor(Color.bluish)
                .padding(.top)
                Spacer()

            }
        }
        .navigationViewStyle(.stack)
        .navigationBarBackButtonHidden(true)
    }
}
