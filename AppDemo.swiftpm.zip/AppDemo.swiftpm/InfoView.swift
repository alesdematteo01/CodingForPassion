//
//  InfoViewù.swift
//  AppDemo
//
//  Created by Alessandra De Matteo on 12/04/22.
//

import Foundation
import SwiftUI

struct InfoView : View{
    
    private let animation = Animation.easeInOut(duration: 2.5).repeatForever()
    private let angles = Array(stride(from: 1.0, through: 360.0, by: 36.0*2))
    private let opacity = 0.15
    
    @State private var progress = 0.0
    
    var body: some View{
        VStack{
            Spacer()
            ZStack {
                Circle()
                    .frame(width: 500, height: 500, alignment: .center)
                    .foregroundColor(Color.lightBlue)
                    .opacity(opacity)
                    .padding()
                ForEach(angles, id: \.self) { i in
                    Circle()
                        .trim(from: 0.0, to: progress)
                        .foregroundColor(Color.lightBlue)
                        .frame(width: 500, height: 500, alignment: .center)
                        .rotationEffect(Angle(degrees: Double(i)))
                        .opacity(opacity)
                }
                Text("🍦")
                    .font(.system(size: 200))
                    .padding()
                    .opacity(progress)
            }
            .onAppear {
                withAnimation(animation) {
                    progress = 1.0
                }
            }
            .padding(.bottom)
            Spacer()
            Text("This application is a demo.")
                .font(.system(size: 30))
                .padding(.top)
            Text("Everything has been made by Alessandra De Matteo")
                .font(.system(size: 30))
                .padding(.bottom)
            Spacer()
            Spacer()
        }
    }
}
