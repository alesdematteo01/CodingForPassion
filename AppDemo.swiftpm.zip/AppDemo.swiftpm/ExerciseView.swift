//
//  ExerciseView.swift
//  AppDemo
//
//  Created by Alessandra De Matteo on 22/04/22.
//

import Foundation
import SwiftUI

struct ExerciseView: View{
    
    @State var exerciseChosen: Exercise
    @State var lessonChosen: Lesson
    
    var body: some View {
        ScrollView(.vertical){
            VStack{
                
                //Intro
                Group{
                    ZStack{
                        Circle()
                            .frame(width: 150, height: 150, alignment: .center)
                            .foregroundColor(exerciseChosen.exerciseColor)
                        Text(exerciseChosen.exerciseEmoji)
                            .font(.system(size: 60))
                    }
                    .padding()
                    HStack{
                        Text("Now that you've figured out how to work with \(lessonChosen.lessonDescription), let's do some practical exercises!")
                            .font(.system(size: 25))
                            .padding(.leading)
                        Spacer()
                    }
                    .padding()
                }
                
                //1st exercise
                Group{
                    HStack{
                        Text("\(exerciseChosen.exerciseEmoji) \(exerciseChosen.exerciseTitle1)")
                            .font(.system(size: 35))
                            .bold()
                            .padding(.leading)
                        Spacer()
                    }
                    .padding()
                    HStack{
                        Text(exerciseChosen.exerciseTopic1)
                            .font(.system(size: 25))
                            .padding(.leading)
                        Spacer()
                    }
                    .padding()
                    HStack{
                        Text(exerciseChosen.hint1)
                            .font(Font.custom("CourierNewPSMT", size: 25))
                            .padding(.leading)
                        Spacer()
                    }
                    .padding()
                }
                
                //2nd exercise
                Group{
                    HStack{
                        Text("\(exerciseChosen.exerciseEmoji) \(exerciseChosen.exerciseTitle2)")
                            .font(.system(size: 35))
                            .bold()
                            .padding(.leading)
                        Spacer()
                    }
                    .padding()
                    HStack{
                        Text(exerciseChosen.exerciseTopic2)
                            .font(.system(size: 25))
                            .padding(.leading)
                        Spacer()
                    }
                    .padding()
                    HStack{
                        Text(exerciseChosen.hint2)
                            .font(Font.custom("CourierNewPSMT", size: 25))
                            .padding(.leading)
                        Spacer()
                    }
                    .padding()
                }
                
                //3ed exercise
                Group{
                    HStack{
                        Text("\(exerciseChosen.exerciseEmoji) \(exerciseChosen.exerciseTitle3)")
                            .font(.system(size: 35))
                            .bold()
                            .padding(.leading)
                        Spacer()
                    }
                    .padding()
                    HStack{
                        Text(exerciseChosen.exerciseTopic3)
                            .font(.system(size: 25))
                            .padding(.leading)
                        Spacer()
                    }
                    .padding()
                    HStack{
                        Text(exerciseChosen.hint3)
                            .font(Font.custom("CourierNewPSMT", size: 25))
                            .padding(.leading)
                        Spacer()
                    }
                    .padding()
                }
            }
        }
        .navigationTitle(lessonChosen.lessonDescription)
    }
}
