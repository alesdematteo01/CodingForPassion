//
//  QuestionaryView.swift
//  AppDemo
//
//  Created by Alessandra De Matteo on 22/04/22.
//

import Foundation
import SwiftUI

struct QuestionaryView: View {
    
    @State var lessonChosen: Lesson
    @State var questionaryChosen: Questionary
    
    @State var counter: Int = 0
    
    @State var a1Done: Bool = false
    @State var a2Done: Bool = false
    @State var a3Done: Bool = false
    @State var a4Done: Bool = false

    
    
    var body: some View{
        ScrollView(.vertical){
            
            //Intro
            Group{
                ZStack{
                    Circle()
                        .frame(width: 150, height: 150, alignment: .center)
                        .foregroundColor(questionaryChosen.questionColor)
                    Text(questionaryChosen.questionEmoji)
                        .font(.system(size: 60))
                }
                .padding()
                HStack{
                    Text("Now that you're done with lesson \(lessonChosen.lessonNumber), let's see what you've learned!")
                        .font(.system(size: 25))
                        .padding(.leading)
                    Spacer()
                }
                .padding()
            }
            
            //1st question
            Group{
                HStack{
                    Text("\(questionaryChosen.questionEmoji) \(questionaryChosen.question1)")
                        .font(.system(size: 35))
                        .bold()
                        .padding(.leading)
                    Spacer()
                }
                .padding()
                VStack{
                    ForEach(questionaryChosen.answers1.indices, id: \.self) { index in
                        let answer = questionaryChosen.answers1[index]
                        
                            Button {
                                if a1Done == false && answer.isCorrect == true{
                                    counter += 1
                                    a1Done = true
                                } else if a1Done == false && answer.isCorrect == false{
                                    a1Done = true
                                }
                            } label: {
                                HStack{
                                    if a1Done == false {
                                        Image(systemName: "circle.dotted")
                                            .resizable()
                                            .foregroundColor(questionaryChosen.questionColor)
                                            .frame(width: 50, height: 50, alignment: .center)
                                            .padding(.leading)
                                    }
                                    if a1Done == true && answer.isCorrect == true{
                                        Image(systemName: "checkmark.circle.fill")
                                            .resizable()
                                            .foregroundColor(questionaryChosen.questionColor)

                                            .frame(width: 50, height: 50, alignment: .center)
                                            .padding(.leading)
                                    }
                                    if a1Done == true && answer.isCorrect == false{
                                        Image(systemName: "x.circle.fill")
                                            .resizable()
                                            .foregroundColor(questionaryChosen.questionColor)
                                            .frame(width: 50, height: 50, alignment: .center)
                                            .padding(.leading)
                                    }
                                    Text(answer.answer)
                                        .font(.system(size: 25))
                                        .foregroundColor(.gray)
                                        .padding(.leading)
                                    Spacer()
                                }
                            }
                        
                    }
                }
            }
            
            //2rd question
            Group{
                HStack{
                    Text("\(questionaryChosen.questionEmoji) \(questionaryChosen.question2)")
                        .font(.system(size: 35))
                        .bold()
                        .padding(.leading)
                    Spacer()
                }
                .padding()
                VStack{
                    ForEach(questionaryChosen.answers2.indices, id: \.self) { index in
                        let answer = questionaryChosen.answers2[index]
                        
                        
                            Button {
                                if a2Done == false && answer.isCorrect == true{
                                    counter += 1
                                    a2Done = true
                                } else if a2Done == false && answer.isCorrect == false{
                                    a2Done = true
                                }
                            } label: {
                                HStack{
                                    if a2Done == false {
                                        Image(systemName: "circle.dotted")
                                            .resizable()
                                            .foregroundColor(questionaryChosen.questionColor)
                                            .frame(width: 50, height: 50, alignment: .center)
                                            .padding(.leading)
                                    }
                                    if a2Done == true && answer.isCorrect == true{
                                        Image(systemName: "checkmark.circle.fill")
                                            .resizable()
                                            .foregroundColor(questionaryChosen.questionColor)

                                            .frame(width: 50, height: 50, alignment: .center)
                                            .padding(.leading)
                                    }
                                    if a2Done == true && answer.isCorrect == false{
                                        Image(systemName: "x.circle.fill")
                                            .resizable()
                                            .foregroundColor(questionaryChosen.questionColor)
                                            .frame(width: 50, height: 50, alignment: .center)
                                            .padding(.leading)
                                    }
                                    Text(answer.answer)
                                        .font(.system(size: 25))
                                        .foregroundColor(.gray)
                                        .padding(.leading)
                                    Spacer()
                                }
                            }
                
                    }
                }
            }
            
            //3rd question
            Group{
                HStack{
                    Text("\(questionaryChosen.questionEmoji) \(questionaryChosen.question3)")
                        .font(.system(size: 35))
                        .bold()
                        .padding(.leading)
                    Spacer()
                }
                .padding()
                VStack{
                    ForEach(questionaryChosen.answers3.indices, id: \.self) { index in
                        let answer = questionaryChosen.answers3[index]
                        
                        
                            Button {
                                if a3Done == false && answer.isCorrect == true{
                                    counter += 1
                                    a3Done = true
                                } else if a3Done == false && answer.isCorrect == false{
                                    a3Done = true
                                }
                            } label: {
                                HStack{
                                    if a3Done == false {
                                        Image(systemName: "circle.dotted")
                                            .resizable()
                                            .foregroundColor(questionaryChosen.questionColor)
                                            .frame(width: 50, height: 50, alignment: .center)
                                            .padding(.leading)
                                    }
                                    if a3Done == true && answer.isCorrect == true{
                                        Image(systemName: "checkmark.circle.fill")
                                            .resizable()
                                            .foregroundColor(questionaryChosen.questionColor)

                                            .frame(width: 50, height: 50, alignment: .center)
                                            .padding(.leading)
                                    }
                                    if a3Done == true && answer.isCorrect == false{
                                        Image(systemName: "x.circle.fill")
                                            .resizable()
                                            .foregroundColor(questionaryChosen.questionColor)
                                            .frame(width: 50, height: 50, alignment: .center)
                                            .padding(.leading)
                                    }
                                    Text(answer.answer)
                                        .font(.system(size: 25))
                                        .foregroundColor(.gray)
                                        .padding(.leading)
                                    Spacer()
                                }
                            }
                        
                    }
                }
            }
            
            //4th question
            Group{
                HStack{
                    Text("\(questionaryChosen.questionEmoji) \(questionaryChosen.question4)")
                        .font(.system(size: 35))
                        .bold()
                        .padding(.leading)
                    Spacer()
                }
                .padding()
                VStack{
                    ForEach(questionaryChosen.answers4.indices, id: \.self) { index in
                        let answer = questionaryChosen.answers4[index]
                        
                    
                            Button {
                                if a4Done == false && answer.isCorrect == true{
                                    counter += 1
                                    a4Done = true
                                } else if a4Done == false && answer.isCorrect == false{
                                    a4Done = true
                                }
                            } label: {
                                HStack{
                                    if a4Done == false {
                                        Image(systemName: "circle.dotted")
                                            .resizable()
                                            .foregroundColor(questionaryChosen.questionColor)
                                            .frame(width: 50, height: 50, alignment: .center)
                                            .padding(.leading)
                                    }
                                    if a4Done == true && answer.isCorrect == true{
                                        Image(systemName: "checkmark.circle.fill")
                                            .resizable()
                                            .foregroundColor(questionaryChosen.questionColor)

                                            .frame(width: 50, height: 50, alignment: .center)
                                            .padding(.leading)
                                    }
                                    if a4Done == true && answer.isCorrect == false{
                                        Image(systemName: "x.circle.fill")
                                            .resizable()
                                            .foregroundColor(questionaryChosen.questionColor)
                                            .frame(width: 50, height: 50, alignment: .center)
                                            .padding(.leading)
                                    }
                                    Text(answer.answer)
                                        .font(.system(size: 25))
                                        .foregroundColor(.gray)
                                        .padding(.leading)
                                    Spacer()
                                }
                            }
                        
                    }
                }
            }
            
            //Ending
            
            Group{
                VStack{
                    Text("Congratulation, you've done :")
                        .bold()
                        .font(.system(size: 35))
                    HStack{
                        if counter == 0{
                            Image(systemName: "circle.dotted")
                                .resizable()
                                .foregroundColor(questionaryChosen.questionColor)
                                .frame(width: 75, height: 75, alignment: .center)
                                .padding()
                            Image(systemName: "circle.dotted")
                                .resizable()
                                .foregroundColor(questionaryChosen.questionColor)
                                .frame(width: 75, height: 75, alignment: .center)
                                .padding()
                            Image(systemName: "circle.dotted")
                                .resizable()
                                .foregroundColor(questionaryChosen.questionColor)
                                .frame(width: 75, height: 75, alignment: .center)
                                .padding()
                            Image(systemName: "circle.dotted")
                                .resizable()
                                .foregroundColor(questionaryChosen.questionColor)
                                .frame(width: 75, height: 75, alignment: .center)
                                .padding()
                        }
                        if counter == 1{
                            ZStack{
                                Circle()
                                    .foregroundColor(questionaryChosen.questionColor)
                                    .frame(width: 75, height: 75, alignment: .center)
                                    .padding()
                                Text(questionaryChosen.questionEmoji)
                                    .font(.system(size: 35))
                            }
                            Image(systemName: "circle.dotted")
                                .resizable()
                                .foregroundColor(questionaryChosen.questionColor)
                                .frame(width: 75, height: 75, alignment: .center)
                                .padding()
                            Image(systemName: "circle.dotted")
                                .resizable()
                                .foregroundColor(questionaryChosen.questionColor)
                                .frame(width: 75, height: 75, alignment: .center)
                                .padding()
                            Image(systemName: "circle.dotted")
                                .resizable()
                                .foregroundColor(questionaryChosen.questionColor)
                                .frame(width: 75, height: 75, alignment: .center)
                                .padding()
                        }
                        
                        if counter == 2{
                            ZStack{
                                Circle()
                                    .foregroundColor(questionaryChosen.questionColor)
                                    .frame(width: 75, height: 75, alignment: .center)
                                    .padding()
                                Text(questionaryChosen.questionEmoji)
                                    .font(.system(size: 35))

                            }
                            ZStack{
                                Circle()
                                    .foregroundColor(questionaryChosen.questionColor)
                                    .frame(width: 75, height: 75, alignment: .center)
                                    .padding()
                                Text(questionaryChosen.questionEmoji)
                                    .font(.system(size: 35))
                            }
                            Image(systemName: "circle.dotted")
                                .resizable()
                                .foregroundColor(questionaryChosen.questionColor)
                                .frame(width: 75, height: 75, alignment: .center)
                                .padding()
                            Image(systemName: "circle.dotted")
                                .resizable()
                                .foregroundColor(questionaryChosen.questionColor)
                                .frame(width: 75, height: 75, alignment: .center)
                                .padding()
                        }
                        
                        if counter == 3{
                            ZStack{
                                Circle()
                                    .foregroundColor(questionaryChosen.questionColor)
                                    .frame(width: 75, height: 75, alignment: .center)
                                    .padding()
                                Text(questionaryChosen.questionEmoji)
                                    .font(.system(size: 35))
                            }
                            ZStack{
                                Circle()
                                    .foregroundColor(questionaryChosen.questionColor)
                                    .frame(width: 75, height: 75, alignment: .center)
                                    .padding()
                                Text(questionaryChosen.questionEmoji)
                                    .font(.system(size: 35))
                            }
                            ZStack{
                                Circle()
                                    .foregroundColor(questionaryChosen.questionColor)
                                    .frame(width: 75, height: 75, alignment: .center)
                                    .padding()
                                Text(questionaryChosen.questionEmoji)
                                    .font(.system(size: 35))
                            }
                            Image(systemName: "circle.dotted")
                                .resizable()
                                .foregroundColor(questionaryChosen.questionColor)
                                .frame(width: 75, height: 75, alignment: .center)
                                .padding()
                        }
                        
                        if counter == 4{
                            ZStack{
                                Circle()
                                    .foregroundColor(questionaryChosen.questionColor)
                                    .frame(width: 75, height: 75, alignment: .center)
                                    .padding()
                                Text(questionaryChosen.questionEmoji)
                                    .font(.system(size: 35))
                            }
                            ZStack{
                                Circle()
                                    .foregroundColor(questionaryChosen.questionColor)
                                    .frame(width: 75, height: 75, alignment: .center)
                                    .padding()
                                Text(questionaryChosen.questionEmoji)
                                    .font(.system(size: 35))
                            }
                            ZStack{
                                Circle()
                                    .foregroundColor(questionaryChosen.questionColor)
                                    .frame(width: 75, height: 75, alignment: .center)
                                    .padding()
                                Text(questionaryChosen.questionEmoji)
                                    .font(.system(size: 35))
                            }
                            ZStack{
                                Circle()
                                    .foregroundColor(questionaryChosen.questionColor)
                                    .frame(width: 75, height: 75, alignment: .center)
                                    .padding()
                                Text(questionaryChosen.questionEmoji)
                                    .font(.system(size: 35))
                            }
                        }
                    }
                    Text("\(counter)/4 correct answers!")
                        .bold()
                        .font(.system(size: 35))
                }
            }
            .padding(.top)

        }
        .navigationTitle(lessonChosen.lessonDescription)
    }
}
