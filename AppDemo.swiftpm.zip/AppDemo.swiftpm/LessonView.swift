//
//  LessonView.swift
//  AppDemo
//
//  Created by Alessandra De Matteo on 21/04/22.
//

import Foundation
import SwiftUI

struct LessonView: View {
    
    @State var lessonChosen: Lesson
    
    var body: some View{
        ScrollView(.vertical){
            VStack{
                
                //Intro
                Group{
                    ZStack{
                        Circle()
                            .frame(width: 150, height: 150, alignment: .center)
                            .foregroundColor(lessonChosen.lessonColor)
                        Text(lessonChosen.lessonEmoji)
                            .font(.system(size: 60))
                    }
                    .padding()
                    HStack{
                        Text(lessonChosen.lessonintro)
                            .font(.system(size: 25))
                            .padding(.leading)
                        Spacer()
                    }
                    .padding()
                    
                }
                
                //1st paragraph
                Group{
                    HStack{
                        Text("\(lessonChosen.lessonEmoji) \(lessonChosen.lessonSubtitle1)")
                            .font(.system(size: 35))
                            .bold()
                            .padding(.leading)
                        Spacer()
                    }
                    .padding()
                    HStack{
                        Text(lessonChosen.lessonPart1)
                            .font(.system(size: 25))
                            .padding(.leading)
                        Spacer()
                    }
                    .padding()
                    HStack{
                        Text(lessonChosen.lessonExample1)
                            .font(Font.custom("CourierNewPSMT", size: 25))
                            .padding(.leading)
                        Spacer()
                    }
                    .padding()
                }
                
                //2nd paragraph
                Group{
                    HStack{
                        Text("\(lessonChosen.lessonEmoji) \(lessonChosen.lessonSubtitle2)")
                            .font(.system(size: 35))
                            .bold()
                            .padding(.leading)
                        Spacer()
                    }
                    .padding()
                    HStack{
                        Text(lessonChosen.lessonPart2)
                            .font(.system(size: 25))
                            .padding(.leading)
                        Spacer()
                    }
                    .padding()
                    HStack{
                        Text(lessonChosen.lessonExample2)
                            .font(Font.custom("CourierNewPSMT", size: 25))
                            .padding(.leading)
                        Spacer()
                    }
                    .padding()

                }
                
                //3rd paragraph
                Group{
                    HStack{
                        Text("\(lessonChosen.lessonEmoji) \(lessonChosen.lessonSubtitle3)")
                            .font(.system(size: 35))
                            .bold()
                            .padding(.leading)
                        Spacer()
                    }
                    .padding()
                    HStack{
                        Text(lessonChosen.lessonPart3)
                            .font(.system(size: 25))
                            .padding(.leading)
                        Spacer()
                    }
                    .padding()
                    HStack{
                        Text("\(lessonChosen.lessonExample3)")
                            .font(Font.custom("CourierNewPSMT", size: 25))
                            .padding(.leading)
                        Spacer()
                    }
                    .padding()
                }
            }
        }
        .navigationTitle(lessonChosen.lessonDescription)
    }
}
