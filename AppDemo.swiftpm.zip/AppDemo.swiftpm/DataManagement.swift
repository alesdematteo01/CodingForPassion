//
//  DataManagement.swift
//  AppDemo
//
//  Created by Alessandra De Matteo on 21/04/22.
//



import Foundation
import SwiftUI

extension Color{
    static let lightGray = Color("lightGray")
    static let lightRed = Color("lightRed")
    static let lightOrange = Color("lightOrange")
    static let lightBlue = Color("lightBlue")
    static let reddish = Color("reddish")
    static let orangish = Color("orangish")
    static let bluish = Color("bluish")

}

struct Lesson {
    let lessonEmoji: String
    let lessonNumber: String
    let lessonDescription: String
    let lessonColor: Color
    let lessonintro: String
    let lessonSubtitle1: String
    let lessonPart1: String
    let lessonExample1: String
    let lessonSubtitle2: String
    let lessonPart2: String
    let lessonExample2: String
    let lessonSubtitle3: String
    let lessonPart3: String
    let lessonExample3: String
}

struct Answer {
    let answer: String
    let isCorrect: Bool
}

struct Questionary {
    let questionEmoji: String
    let questionColor: Color
    let question1: String
    let answers1 : [Answer]
    let question2: String
    let answers2: [Answer]
    let question3: String
    let answers3: [Answer]
    let question4: String
    let answers4: [Answer]
}

struct Exercise {
    let exerciseEmoji: String
    let exerciseColor: Color
    let exerciseTitle1:String
    let exerciseTopic1: String
    let hint1: String
    let exerciseTitle2:String
    let exerciseTopic2: String
    let hint2: String
    let exerciseTitle3:String
    let exerciseTopic3: String
    let hint3: String
}

let lesson1 = Lesson.init(lessonEmoji: "🍒", lessonNumber: "1", lessonDescription: "The Basics of Basics", lessonColor: .lightRed, lessonintro: "Welcome to your first coding lesson! Here you’re going to learn what Swift is and what are his advantages when compared with other coding languages. Also, you’ll see some tools which will be very useful during your learning journey.", lessonSubtitle1: "What is Swift?", lessonPart1: "Swift is a protocol-oriented and object-oriented programming language. To a person who never heard these words before, these may sound like simple gibberish, but, trust me, that’s the complete opposite! In fact, they’re really important concepts in the coding world, so important that even complete beginners needs to know at least what they mean. Let’s start with what a object-oriented programming: a object-oriented coding language is defined with such words when is based on the concept of \"objects\", which can contain data and code: data in the form of fields (often known as attributes or properties), and code, in the form of procedures (often known as methods). Let’s do an example to make this more clearer. Imagine that we have a “person” as an object of our code. The color of their hair, of their eyes, how old they are, how tall they are - all elements that describe and give a new characteristic to the person - is an “attribute” of our person; while the actions this person can do - like walk, run or raise his arm - are called “methods”. Looking at this way is a very simple concept, right? And yet, this very easy way of thinking is what made us able to create such amazing computer programs, like games, social media, photo editors, etc. But that’s not all: what Swift special when compared with other famous coding languages is that it’s also protocol-oriented. What is a protocol? A protocol is a common means for discrete objects to communicate with each other. These are definitions of methods and values which the objects agree upon, in order to co-operate with other object. For example, if an object has the protocol “Comparable”, then it has to have something - an attribute or a method, specified by the protocol - that makes it comparable to other objects. That’s are the basics that every coding amateurs has to know, before even putting their hands on the code! But worry not, now that you learned it, you can finally start your coding adventure and be able to write some amazing programs! Here a little example of a very easy code, that you’ll meet during your coding path:", lessonExample1: """
struct person {
    let name: String
    var age: Int
    let eyeColor: Color
    let hairColor: Color
}
""", lessonSubtitle2: "The \"print\"", lessonPart2: "The “print()” action is a line of code very useful for every programmer, no matter if you’re a beginner or an experienced coder. It does the simple action to show something - that could be a phrase or a value, you decide - on the console of our editor. Most of the time, it will come handy when you’ll need to track a specific attribute or to check if the program flow is working as it should.", lessonExample2: """
print(“Hello!”)  // This line of code will show “Hello!” In your console
""", lessonSubtitle3: "It's time to Comment", lessonPart3: "Did you notice the line written with there simbols \"//\"? That means a comment has been added to your code. It pratically does nothing, it just adds... a comment! It's a very good practice to add a lot of comments to your code, to make it more readable and understandable.", lessonExample3: """
//This is a one line comment

/* This is a
multilined comment*/
""")

let lesson2 = Lesson.init(lessonEmoji: "🍱", lessonNumber: "2", lessonDescription: "So many Variables!", lessonColor: .lightRed, lessonintro: "Now that you've covered the basics, it's time to learn a fundamental aspect of coding: the variables! In this lesson, you'll learn what are the differences between constants and variables, what are the most-common used types of variables and how to create an array!", lessonSubtitle1: "Constants and Variables", lessonPart1: "Constants and variables associate a name (such as myAge or greetingMessage) with a value of a particular type (such as the number 24 or the string \"Hello\"). The value of a constant can’t be changed once it’s set, whereas a variable can be set to a different value in the future. To use them in your code, you must declare them. To do that, you declare constants with the let keyword and variables with the var keyword. Here’s an example of how constants and variables can be declared:", lessonExample1: """
let greetingMessage = "Hello!"
var myAge = 24
""", lessonSubtitle2: "Types of Constants and Variables", lessonPart2: """
Constants and variables can have differents types, depending on the value they store. Here are some of the most known types:

• Integers : they are whole numbers with no fractional component, such as 10 and -5. Integers are either signed (positive, zero, or negative) or unsigned (positive or zero). We usually refers them with the "Int" label, while for the unsigned ones we use "UInt".

• Floating-Point Numbers: they are numbers with a fractional component, such as 3.14159, 0.1, and -273.15. We usually refers them as "Float".

• Booleans : they're referred to as logical, because they can only ever be true or false. Swift provides two Boolean constant values, true and false. We usually refers them as "Bool".

• String Literals : You can include predefined "String" values within your code as string literals. A string literal is a sequence of characters surrounded by double quotation marks (").

Here some example of declaretion of every single type of variable:
""", lessonExample2: """
//without specifications

let age = 24
var result = 5.6
let amIcute = true
let greeting = "Hello"

//with specifications

let age: Int = 24
var result: Float = 5.6
let amIcute: Bool = true
let greeting: String = "Hello"
""", lessonSubtitle3: "Arrays", lessonPart3: "An array stores values of the same type in an ordered list. The same value can appear in an array multiple times at different positions. We can actually do a lot of things with arrays, but, in this lesson, we're just going to see how to create one.", lessonExample3: """
//empty array

let empty: [Int] = []

//array with various types
let numbers: [Int] = [1, 3, 7]
let results: [Floats] = [0.1, 3.4, 1.5]
var trueOrFalse: [Bool] = [true, false, true]
let greetings: [String] = ["Hello", "Ciao", "Bonjour"]
""")

let lessonsAvaibles: [Lesson] = [lesson1, lesson2]

//1st Questionary Answers
let q1answer11 = Answer.init(answer: "an object-oriented coding language", isCorrect: false)
let q1answer12 = Answer.init(answer: "a protocol-oriented and object-oriented coding language", isCorrect: true)
let q1answer13 = Answer.init(answer: "a protocol-oriented coding language", isCorrect: false)
let q1answer14 = Answer.init(answer: "an attribute", isCorrect: false)

let q1answer1x = [q1answer11, q1answer12, q1answer13, q1answer14]

let q1answer21 = Answer.init(answer: "is a common means for classes to write each other", isCorrect: false)
let q1answer22 = Answer.init(answer: "is a common means for objects to istanciate each other", isCorrect: false)
let q1answer23 = Answer.init(answer: "is a common means for discrete objects to communicate with each other", isCorrect: true)
let q1answer24 = Answer.init(answer: "is a common means for discrete classes to define each other", isCorrect: false)

let q1answer2x = [q1answer21, q1answer22, q1answer23, q1answer24]

let q1answer31 = Answer.init(answer: "()print", isCorrect: false)
let q1answer32 = Answer.init(answer: "(print)", isCorrect: false)
let q1answer33 = Answer.init(answer: "print", isCorrect: false)
let q1answer34 = Answer.init(answer: "print()", isCorrect: true)

let q1answer3x = [q1answer31, q1answer32, q1answer33, q1answer34]

let q1answer41 = Answer.init(answer: "// and /*  */", isCorrect: true)
let q1answer42 = Answer.init(answer: "||", isCorrect: false)
let q1answer43 = Answer.init(answer: "/* */", isCorrect: false)
let q1answer44 = Answer.init(answer: "//", isCorrect: false)

let q1answer4x = [q1answer41, q1answer42, q1answer43, q1answer44]

//2nd Questionary Answers
let q2answer11 = Answer.init(answer: "with the let label", isCorrect: true)
let q2answer12 = Answer.init(answer: "with the var label", isCorrect: false)
let q2answer13 = Answer.init(answer: "with the func label", isCorrect: false)
let q2answer14 = Answer.init(answer: "with the bool label", isCorrect: false)

let q2answer1x = [q2answer11, q2answer12, q2answer13, q2answer14]

let q2answer21 = Answer.init(answer: "a bool is a numerical value", isCorrect: false)
let q2answer22 = Answer.init(answer: "a bool is a logical value that can be only false", isCorrect: false)
let q2answer23 = Answer.init(answer: "a bool is a logical value that can be only true", isCorrect: false)
let q2answer24 = Answer.init(answer: "a bool is a logical value that can be true or false", isCorrect: true)

let q2answer2x = [q2answer21, q2answer22, q2answer23, q2answer24]

let q2answer31 = Answer.init(answer: "conteiners", isCorrect: false)
let q2answer32 = Answer.init(answer: "numbers", isCorrect: false)
let q2answer33 = Answer.init(answer: "signed", isCorrect: false)
let q2answer34 = Answer.init(answer: "signed and unsigned", isCorrect: true)

let q2answer3x = [q2answer31, q2answer32, q2answer33, q2answer34]

let q2answer41 = Answer.init(answer: "yes, but only if you declare every single variable out of the array", isCorrect: false)
let q2answer42 = Answer.init(answer: "yes, it can store multiple types", isCorrect: false)
let q2answer43 = Answer.init(answer: "no, it can store just two types", isCorrect: false)
let q2answer44 = Answer.init(answer: "no, it can store variables of only one type", isCorrect: true)

let q2answer4x = [q2answer41, q2answer42, q2answer43, q2answer44]

let questionary1 = Questionary.init(questionEmoji: "🍊", questionColor: .lightOrange, question1: "What is Swift?", answers1: q1answer1x, question2: "What is a protocol?", answers2: q1answer2x, question3: "How do you write the print line of code?", answers3: q1answer3x, question4: "Which symbols do you need to write comments in your code?", answers4: q1answer4x)

let questionary2 = Questionary.init(questionEmoji: "🍿", questionColor: .lightOrange, question1: "How do you declare a constant?", answers1: q2answer1x, question2: "What is a bool?", answers2: q2answer2x, question3: "Integers can be...", answers3: q2answer3x, question4: "Is it true that an array can store variables of different types?", answers4: q2answer4x)

let questionariesAvaibles: [Questionary] = [questionary1, questionary2]

let exercise1 = Exercise.init(exerciseEmoji: "🫐", exerciseColor: .lightBlue, exerciseTitle1: "Hello World!", exerciseTopic1: "The first program of basically every single coder in the existence! After you created the your first project, go to the ContentView and add inside \"Text(\"Hello World\")\" - this is a function of the SwiftUI framowork. Remember to import the framework, at the top of the screen! Here the solution of this exercise:", hint1: """
import SwiftUI

struct ContentView: View {
    var body: some View{
        Text(\"Hello World!\")
    }
}
""", exerciseTitle2: "Comment time!", exerciseTopic2: "Let's add a comment in our code by using the one line method!", hint2: """
import SwiftUI

struct ContentView: View {
    var body: some View{
        Text(\"Hello World!\")
        // Yay, we did our first program!
    }
}
""", exerciseTitle3: "Let's play with the font", exerciseTopic3: "This is a bonus content of this lesson - so you can go on, if you wish to switch rapidly to the other activities of the application. If you would like to stylize your code, go on the line below your Text code, add a dot and something to your text! You can play with the color, with the size, with the font, etc!", hint3: """
import SwiftUI

struct ContentView: View {
    var body: some View{
        Text(\"Hello World!\")
            .font(.system(size: 25)
            .foregroundColor(.red)
            .padding()
    }
}
""")

let exercise2 = Exercise.init(exerciseEmoji: "🥙", exerciseColor: .lightBlue, exerciseTitle1: "Declare your first variable", exerciseTopic1: "As the title says, let's declare your first variable! Remember the difference between constants and variables and this exercise will be a piece of cake for you! Here's an hint, if you're struggling:", hint1: "var number = 10", exerciseTitle2: "Know all the Types", exerciseTopic2: "Declare a constant of each type, to learn how write them better.", hint2: """
var number = 10
var result = 1.8
var isOrangeOrange = true
var greeting = "hello"
""", exerciseTitle3: "Array time", exerciseTopic3: "In this exercise, try to create an array of strings.", hint3: "var greetings: [String] = [\"Hello\", \"Ciao\"]")

let exerciseAvaibles: [Exercise] = [exercise1, exercise2]
